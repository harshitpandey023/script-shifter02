/* JobTrack guard: protects pages and handles logout. */

(function () {

    const user = getCurrentUser();

    // Redirect users who are not logged in.
    if (!user) {
        window.location.href = "login.html";
        return;
    }

    document.addEventListener("DOMContentLoaded", () => {

        // Display the user's first name, if the element exists.
        const nameEl = document.getElementById("userName");

        if (nameEl) {
            nameEl.textContent =
                (user.name || "USER").split(" ")[0].toUpperCase() + ".";
        }

        // Logout functionality.
        const logoutButton = document.getElementById("logoutButton");

        if (logoutButton && !logoutButton.dataset.bound) {

            logoutButton.dataset.bound = "true";

            logoutButton.addEventListener("click", () => {
                logoutUser();
                window.location.href = "login.html";
            });

        }

    });

})();