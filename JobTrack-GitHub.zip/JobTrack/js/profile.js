
/* =========================================
   JOBTRACK — PROFILE MANAGEMENT
   Script Shifters / K3P26RE
========================================= */

document.addEventListener("DOMContentLoaded", () => {

    const user = getCurrentUser();

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    const $ = id => document.getElementById(id);

    const form = $("profileForm");
    const message = $("pMsg");

    // Load the signed-in user's profile
    const allProfiles = getStoredData(
        STORAGE_KEYS.PROFILE,
        {}
    );

    const profile = allProfiles[user.id] || {};

    // Populate existing information
    $("pName").value = profile.name || user.name || "";
    $("pEmail").value = user.email || "";
    $("pHeadline").value = profile.headline || "";
    $("pPhone").value = profile.phone || "";
    $("pLocation").value = profile.location || "";
    $("pProgramme").value =
        profile.programme || user.programme || "";

    $("pSkills").value =
        (profile.skills || []).join(", ");

    $("pAbout").value = profile.about || "";


    // Save profile
    form.addEventListener("submit", event => {

        event.preventDefault();

        const updatedProfile = {

            userId: user.id,

            name: $("pName").value.trim(),

            email: user.email,

            headline: $("pHeadline").value.trim(),

            phone: $("pPhone").value.trim(),

            location: $("pLocation").value.trim(),

            programme: $("pProgramme").value.trim(),

            skills: $("pSkills").value
                .split(",")
                .map(skill => skill.trim())
                .filter(Boolean),

            about: $("pAbout").value.trim(),

            updatedAt: new Date().toISOString()

        };


        if (!updatedProfile.name) {

            message.textContent = "ERROR / Name is required.";
            return;

        }


        // Save profile separately for each user
        allProfiles[user.id] = updatedProfile;

        const saved = setStoredData(
            STORAGE_KEYS.PROFILE,
            allProfiles
        );


        if (saved) {

            // Update the signed-in user's display name
            const users = getUsers();

            const userIndex = users.findIndex(
                item => item.id === user.id
            );

            if (userIndex !== -1) {

                users[userIndex].name = updatedProfile.name;
                saveUsers(users);

            }

            const currentUser = {
                ...user,
                name: updatedProfile.name
            };

            setCurrentUser(currentUser);

            addActivity({
                userId: user.id,
                type: "profile",
                message: updatedProfile.name +
                    " updated their profile."
            });

            message.textContent =
                "SUCCESS / Profile saved successfully.";

        } else {

            message.textContent =
                "ERROR / Could not save profile.";

        }

    });

});
