
/* =========================================
   JOBTRACK — APPLICATION MANAGER
   Script Shifters / K3P26RE
========================================= */


/* =========================================
   CURRENT USER & DOM ELEMENTS
========================================= */

const currentUser = getCurrentUser();

const applicationsList =
    document.getElementById("applicationsList");

const applicationCount =
    document.getElementById("applicationCount");

const resultCount =
    document.getElementById("resultCount");

const statusFilter =
    document.getElementById("statusFilter");


/* =========================================
   GLOBAL DATA
========================================= */

let allApplications = [];


/* =========================================
   ALLOWED APPLICATION STATUSES
========================================= */

const allowedStatuses = [
    "Applied",
    "Assessment",
    "Interview",
    "Offer",
    "Rejected"
];


/* =========================================
   SAFE HTML HELPER
========================================= */

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}


/* =========================================
   CHECK APPLICATION OWNERSHIP
========================================= */

function belongsToCurrentUser(application) {

    if (!currentUser || !application) {
        return false;
    }

    // New application records use userId.
    if (application.userId) {
        return application.userId === currentUser.id;
    }

    // Support older records using applicant email.
    return (
        application.applicantEmail &&
        application.applicantEmail.toLowerCase() ===
        currentUser.email.toLowerCase()
    );
}


/* =========================================
   LOAD APPLICATIONS
========================================= */

function loadApplications() {

    if (!currentUser) {
        window.location.href = "login.html";
        return;
    }

    const storedApplications = getApplications();

    // Show only applications belonging to
    // the currently signed-in user.
    allApplications = storedApplications.filter(
        belongsToCurrentUser
    );

    renderApplications();
}


/* =========================================
   RENDER APPLICATIONS
========================================= */

function renderApplications() {

    if (!applicationsList) return;

    const selectedStatus = statusFilter
        ? statusFilter.value
        : "all";

    let applications = [...allApplications];

    // Filter by status, treating invalid statuses as Applied.
    if (selectedStatus !== "all") {

        applications = applications.filter(application =>
            (allowedStatuses.includes(application.status)
                ? application.status
                : "Applied") === selectedStatus
        );

    }

    // Newest applications first.
    applications.sort((a, b) => {

        const dateA = new Date(
            a.createdAt || a.appliedDate || 0
        );

        const dateB = new Date(
            b.createdAt || b.appliedDate || 0
        );

        return dateB - dateA;

    });


    // Update counters.
    if (applicationCount) {

        applicationCount.textContent =
            String(allApplications.length).padStart(2, "0");

    }

    if (resultCount) {

        resultCount.textContent =
            `${String(applications.length).padStart(2, "0")} RESULTS`;

    }


    // Empty state.
    if (applications.length === 0) {

        applicationsList.innerHTML = `
            <div class="applications-empty">
                <strong>
                    ${selectedStatus === "all"
                        ? "NO APPLICATIONS YET"
                        : "NO MATCHING APPLICATIONS"}
                </strong>
                ${selectedStatus === "all"
                    ? "Apply to a job to create your first application record."
                    : `No applications currently have the status "${escapeHTML(selectedStatus)}".`}
            </div>
        `;

        return;
    }


    // Display application cards.
    applicationsList.innerHTML = applications
        .map(application => createApplicationCard(application))
        .join("");

}


/* =========================================
   APPLICATION CARD
========================================= */

function createApplicationCard(application) {

    const company = application.company || "UNKNOWN";

    const role =
        application.role ||
        application.title ||
        "UNTITLED ROLE";

    const status = allowedStatuses.includes(application.status)
        ? application.status
        : "Applied";

    const initial = company.charAt(0).toUpperCase();


    // Format application date.
    let date = "NO DATE";

    if (application.appliedDate) {

        const parsedDate = new Date(
            application.appliedDate + "T00:00:00"
        );

        date = Number.isNaN(parsedDate.getTime())
            ? "NO DATE"
            : parsedDate.toLocaleDateString("en-IN", {
                day: "2-digit",
                month: "short",
                year: "numeric"
            });

    } else if (application.createdAt) {

        const parsedDate = new Date(application.createdAt);

        date = Number.isNaN(parsedDate.getTime())
            ? "NO DATE"
            : parsedDate.toLocaleDateString("en-IN", {
                day: "2-digit",
                month: "short",
                year: "numeric"
            });

    }


    return `
        <article class="application-card">

            <div class="application-company-icon">
                ${escapeHTML(initial)}
            </div>

            <div>

                <div class="application-company">
                    ${escapeHTML(company)}
                </div>

                <div class="application-role">
                    ${escapeHTML(role)}
                </div>

            </div>

            <div class="application-date">
                ${escapeHTML(date)}
            </div>

            <div class="application-status-wrap">

                <select
                    class="application-status-select"
                    data-id="${escapeHTML(application.id)}"
                    aria-label="Update application status"
                >

                    <option value="Applied"
                        ${status === "Applied" ? "selected" : ""}>
                        APPLIED
                    </option>

                    <option value="Assessment"
                        ${status === "Assessment" ? "selected" : ""}>
                        ASSESSMENT
                    </option>

                    <option value="Interview"
                        ${status === "Interview" ? "selected" : ""}>
                        INTERVIEW
                    </option>

                    <option value="Offer"
                        ${status === "Offer" ? "selected" : ""}>
                        OFFER
                    </option>

                    <option value="Rejected"
                        ${status === "Rejected" ? "selected" : ""}>
                        REJECTED
                    </option>

                </select>

            </div>

        </article>
    `;

}


/* =========================================
   UPDATE APPLICATION STATUS
========================================= */

function updateApplicationStatus(applicationId, newStatus) {

    if (!currentUser) {
        window.location.href = "login.html";
        return;
    }

    if (!allowedStatuses.includes(newStatus)) {
        return;
    }

    const applications = getApplications();

    // Find the application belonging to this user.
    // Supports both new and older application records.
    const index = applications.findIndex(application =>

        application.id === applicationId &&
        belongsToCurrentUser(application)

    );

    // Do not modify another user's application.
    if (index === -1) {
        alert("Application record not found.");
        return;
    }

    const oldStatus = applications[index].status || "Applied";

    if (oldStatus === newStatus) {
        return;
    }

    // Update status and timestamp.
    applications[index].status = newStatus;

    applications[index].updatedAt =
        new Date().toISOString();


    // Save changes.
    const saved = saveApplications(applications);

    if (!saved) {
        alert("Unable to save application status. Please try again.");
        loadApplications();
        return;
    }


    // Record status change in activity log.
    addActivity({

        userId: currentUser.id,

        type: "status",

        message:
            `Application for ${applications[index].role || applications[index].title || "Untitled Role"} at ${applications[index].company || "Unknown Company"} changed from ${oldStatus} to ${newStatus}.`

    });


    // Refresh displayed applications.
    loadApplications();

}


/* =========================================
   STATUS FILTER
========================================= */

if (statusFilter) {

    statusFilter.addEventListener("change", renderApplications);

}


/* =========================================
   STATUS UPDATE EVENT
========================================= */

if (applicationsList) {

    applicationsList.addEventListener("change", event => {

        if (
            event.target.classList.contains(
                "application-status-select"
            )
        ) {

            const applicationId = event.target.dataset.id;

            const newStatus = event.target.value;

            updateApplicationStatus(
                applicationId,
                newStatus
            );

        }

    });

}


/* =========================================
   START APPLICATION MANAGER
========================================= */

loadApplications();
