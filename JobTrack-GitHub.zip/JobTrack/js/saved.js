/* Saved jobs page: shows jobs the user starred (ids in localStorage). */
document.addEventListener("DOMContentLoaded", async () => {
    const list = document.getElementById("savedList");
    const render = (jobs) => {
        const ids = getSavedJobs();
        const mine = jobs.filter(j => ids.includes(j.id));
        if (!mine.length) {
            list.className = "page-empty";
            list.innerHTML = 'No saved jobs yet. Star some on the <a href="jobs.html">Jobs page</a>.';
            return;
        }
        list.className = "page-grid";
        list.innerHTML = mine.map(j => `
            <div class="page-card">
                <small>${j.type} / ${j.location}</small>
                <h3>${j.title}</h3><span>${j.company}</span><small>${j.salary}</small>
                <div class="row">
                    <a href="apply.html?job=${j.id}">APPLY</a>
                    <button data-id="${j.id}">REMOVE</button>
                </div>
            </div>`).join("");
        list.querySelectorAll("button").forEach(b => b.addEventListener("click", () => {
            toggleSavedJob(b.dataset.id); render(jobs);
        }));
    };
    try {
        const res = await fetch("data/jobs.json");
        render(await res.json());
    } catch (e) {
        list.className = "page-empty";
        list.textContent = "Could not load jobs. Open the project with VS Code Live Server.";
    }
});
