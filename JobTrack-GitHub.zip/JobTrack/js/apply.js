
/* =========================================
   JOBTRACK — APPLICATION FORM
   Script Shifters / K3P26RE
========================================= */


/* =========================================
   ELEMENTS
========================================= */

const jobTitle = document.getElementById("jobTitle");
const companyName = document.getElementById("companyName");
const companyInitial = document.getElementById("companyInitial");

const previewTitle = document.getElementById("previewTitle");
const previewCategory = document.getElementById("previewCategory");
const previewType = document.getElementById("previewType");
const previewLocation = document.getElementById("previewLocation");

const applicationForm = document.getElementById("applicationForm");
const message = document.getElementById("applicationMessage");

const applicantName = document.getElementById("applicantName");
const applicantEmail = document.getElementById("applicantEmail");
const appliedDate = document.getElementById("appliedDate");

const applicationStatus = document.getElementById("applicationStatus");
const applicationNotes = document.getElementById("applicationNotes");


/* =========================================
   CURRENT USER
========================================= */

const currentUser = getCurrentUser();


/* =========================================
   SELECTED JOB
========================================= */

let selectedJob = null;


/* =========================================
   GET JOB ID FROM URL
========================================= */

const params = new URLSearchParams(window.location.search);
const jobId = params.get("job");


/* =========================================
   SET LOCAL DATE
========================================= */

function getTodayDate() {
    const now = new Date();

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

if (appliedDate) {
    appliedDate.value = getTodayDate();
}

// Set the latest permitted application date.
if (appliedDate) {
    appliedDate.max = getTodayDate();
}

// Pre-fill details of the logged-in student.
if (currentUser) {
    if (applicantName) {
        applicantName.value = currentUser.name || "";
    }

    if (applicantEmail) {
        applicantEmail.value = currentUser.email || "";
    }
}

/* =========================================
   LOAD SELECTED JOB
========================================= */

async function loadSelectedJob() {

    try {
        if (!jobId) {
            throw new Error("No job ID was provided.");
        }

        const response = await fetch("data/jobs.json");

        if (!response.ok) {
            throw new Error("Unable to load jobs database.");
        }

        const jobs = await response.json();

        if (!Array.isArray(jobs)) {
            throw new Error("Invalid jobs database format.");
        }

        selectedJob = jobs.find(job => String(job.id) === String(jobId));

        if (!selectedJob) {
            showError("ERROR / Job opportunity not found.");
            return;
        }

        populateJob();

    } catch (error) {
        console.error("Application loading error:", error);
        showError("ERROR / Unable to access opportunity database.");
    }
}


/* =========================================
   POPULATE JOB DETAILS
========================================= */

function populateJob() {

    const initial = (selectedJob.company || "?")
        .charAt(0)
        .toUpperCase();

    if (companyInitial) {
        companyInitial.textContent = initial;
    }

    if (companyName) {
        companyName.textContent = selectedJob.company || "";
    }

    if (previewTitle) {
        previewTitle.textContent = selectedJob.title || "";
    }

    if (jobTitle) {
        jobTitle.textContent = (selectedJob.title || "").toUpperCase();
    }

    if (previewCategory) {
        previewCategory.textContent =
            (selectedJob.category || "").toUpperCase();
    }

    if (previewType) {
        previewType.textContent =
            (selectedJob.type || "").toUpperCase();
    }

    if (previewLocation) {
        previewLocation.textContent =
            (selectedJob.location || "").toUpperCase();
    }

}


/* =========================================
   DISPLAY ERROR / MESSAGE
========================================= */

function showError(text) {

    if (!message) return;

    message.textContent = text;
    message.style.color = "#ff6b9d";
}


/* =========================================
   SUBMIT APPLICATION
========================================= */

if (applicationForm) {

    applicationForm.addEventListener("submit", event => {

        event.preventDefault();

        if (!currentUser) {
            showError("ERROR / Please log in before applying.");
            return;
        }

        if (!selectedJob) {
            showError("ERROR / No job selected.");
            return;
        }

        const name = applicantName.value.trim();
        const email = applicantEmail.value.trim();
        const date = appliedDate.value;
        const status = applicationStatus
            ? applicationStatus.value
            : "Applied";

        const notes = applicationNotes
            ? applicationNotes.value.trim()
            : "";


        /* =================================
           VALIDATION
        ================================= */

        if (!name || !email || !date) {
            showError("ERROR / Please complete all required fields.");
            return;
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {
            showError("ERROR / Enter a valid email address.");
            return;
        }

        if (date > getTodayDate()) {
            showError("ERROR / Application date cannot be in the future.");
            return;
        }


        /* =================================
           PREVENT DOUBLE SUBMISSION
        ================================= */

        const submitButton =
            applicationForm.querySelector('[type="submit"]');

        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = "SUBMITTING...";
        }


        /* =================================
           CREATE APPLICATION
        ================================= */

        try {

            const application = addApplication({

                userId: currentUser.id,

                jobId: selectedJob.id,
                company: selectedJob.company,
                role: selectedJob.title,
                category: selectedJob.category,
                type: selectedJob.type,
                location: selectedJob.location,
                salary: selectedJob.salary,

                applicantName: name,
                applicantEmail: email,

                appliedDate: date,
                status: status,
                notes: notes

            });


            if (!application) {
                throw new Error("Application could not be created.");
            }


            /* =================================
               RECORD ACTIVITY
            ================================= */

            addActivity({
                userId: currentUser.id,
                type: "application",
                message: `${name} applied for ${selectedJob.title} at ${selectedJob.company}.`
            });


            /* =================================
               SUCCESS
            ================================= */

            if (message) {
                message.style.color = "#9b6cff";
                message.textContent =
                    "APPLICATION SAVED / Redirecting...";
            }

            setTimeout(() => {
                window.location.href = "applications.html";
            }, 700);

        } catch (error) {

            console.error("Application submission error:", error);

            showError("ERROR / Application could not be saved.");

            if (submitButton) {
                submitButton.disabled = false;
                submitButton.textContent = "SUBMIT APPLICATION";
            }

        }

    });

}


/* =========================================
   START
========================================= */

loadSelectedJob();
