
/* =========================================
   JOBTRACK REGISTRATION
   Script Shifters / K3P26RE
========================================= */

document.addEventListener("DOMContentLoaded", () => {

    // Add demo accounts if they do not already exist.
    seedDemoUsers();

    const form = document.getElementById("registerForm");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const togglePassword = document.getElementById("toggleRegisterPassword");
    const message = document.getElementById("registerMessage");
    const terms = document.getElementById("terms");

    /* =================================
       SHOW / HIDE PASSWORD
    ================================= */

    if (togglePassword && password) {

        togglePassword.addEventListener("click", () => {

            const showing = password.type === "password";

            password.type = showing ? "text" : "password";

            togglePassword.textContent =
                showing ? "HIDE" : "SHOW";

        });

    }

    if (!form) return;

    /* =================================
       REGISTRATION FORM
    ================================= */

    form.addEventListener("submit", event => {

        event.preventDefault();

        if (message) {
            message.textContent = "";
        }

        if (!password || !confirmPassword || !terms) {
            showMessage(
                "ERROR / Registration form is missing required fields.",
                "error"
            );
            return;
        }

        const formData = new FormData(form);

        const name = String(formData.get("name") || "").trim();
        const email = String(formData.get("email") || "").trim().toLowerCase();
        const studentId = String(formData.get("studentId") || "").trim();
        const year = String(formData.get("year") || "").trim();
        const programme = String(formData.get("programme") || "").trim();
        const passwordValue = password.value;

        /* =================================
           REQUIRED FIELD VALIDATION
        ================================= */

        if (
            !name ||
            !email ||
            !studentId ||
            !year ||
            !programme ||
            !passwordValue
        ) {
            showMessage(
                "ERROR / Please complete all required fields.",
                "error"
            );
            return;
        }

        /* =================================
           EMAIL VALIDATION
        ================================= */

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {
            showMessage(
                "ERROR / Please enter a valid email address.",
                "error"
            );
            return;
        }

        /* =================================
           PASSWORD VALIDATION
        ================================= */

        if (passwordValue.length < 8) {
            showMessage(
                "ERROR / Password must contain at least 8 characters.",
                "error"
            );
            password.focus();
            return;
        }

        if (passwordValue !== confirmPassword.value) {
            showMessage(
                "ERROR / Your passwords do not match.",
                "error"
            );
            confirmPassword.focus();
            return;
        }

        /* =================================
           TERMS VALIDATION
        ================================= */

        if (!terms.checked) {
            showMessage(
                "ERROR / Please accept the terms to continue.",
                "error"
            );
            return;
        }

        /* =================================
           CREATE STUDENT ACCOUNT
        ================================= */

        const result = createUser({
            name,
            email,
            studentId,
            year,
            programme,
            password: passwordValue
        });

        if (!result || !result.success) {
            showMessage(
                `ERROR / ${result?.message || "Account creation failed. Please try again."}`,
                "error"
            );
            return;
        }

        /* =================================
           CREATE LOGIN SESSION
        ================================= */

        const session = setCurrentUser(result.user);

        if (!session) {
            showMessage(
                "ERROR / Account created, but login could not be started. Please log in.",
                "error"
            );
            return;
        }

        /* =================================
           RECORD REGISTRATION ACTIVITY
        ================================= */

        addActivity({
            userId: result.user.id,
            type: "registration",
            message: `${result.user.name} created an account.`
        });

        /* =================================
           SUCCESS & REDIRECT
        ================================= */

        showMessage(
            "SUCCESS / Account created. Opening your workspace...",
            "success"
        );

        form.reset();

        window.location.href = "dashboard.html";

    });

    /* =================================
       MESSAGE HELPER
    ================================= */

    function showMessage(text, type) {

        if (!message) return;

        message.textContent = text;

        message.style.color =
            type === "success"
                ? "#9b6cff"
                : "#ff7777";

    }

});
