
/* =========================================
   JOBTRACK DASHBOARD
   Script Shifters / K3P26RE
========================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =================================
       CHECK LOGIN
    ================================= */

    const currentUser = getCurrentUser();

    if (!currentUser) {
        window.location.href = "login.html";
        return;
    }


    /* =================================
       GET USER APPLICATIONS
    ================================= */

    const allApplications = getApplications();

    const userApplications = allApplications.filter(application => {

        if (application.userId) {
            return application.userId === currentUser.id;
        }

        return (
            application.applicantEmail &&
            application.applicantEmail.toLowerCase() ===
            currentUser.email.toLowerCase()
        );

    });


    /* =================================
       GET SAVED JOBS
    ================================= */

    // getSavedJobs() returns saved jobs
    // belonging to the currently logged-in user.
    const savedJobs = getSavedJobs();

    const totalSaved = savedJobs.length;


    /* =================================
       NORMALIZE APPLICATION STATUS
    ================================= */

    const allowedStatuses = [
        "Applied",
        "Assessment",
        "Interview",
        "Offer",
        "Rejected"
    ];

    function getApplicationStatus(application) {

        return allowedStatuses.includes(application.status)
            ? application.status
            : "Applied";

    }


    /* =================================
       CALCULATE STATISTICS
    ================================= */

    const totalApplications = userApplications.length;

    const totalInterviews = userApplications.filter(
        application =>
            getApplicationStatus(application) === "Interview"
    ).length;

    const totalOffers = userApplications.filter(
        application =>
            getApplicationStatus(application) === "Offer"
    ).length;

    const totalApplied = userApplications.filter(
        application =>
            getApplicationStatus(application) === "Applied"
    ).length;

    const totalRejected = userApplications.filter(
        application =>
            getApplicationStatus(application) === "Rejected"
    ).length;


    /* =================================
       UPDATE COUNTERS
    ================================= */

    function updateCounter(elementId, value) {

        const element = document.getElementById(elementId);

        if (element) {
            element.textContent =
                String(value).padStart(2, "0");
        }

    }

    updateCounter("totalApplications", totalApplications);
    updateCounter("totalInterviews", totalInterviews);
    updateCounter("totalOffers", totalOffers);
    updateCounter("totalSaved", totalSaved);

    // Application pipeline
    updateCounter("appliedCount", totalApplied);
    updateCounter("interviewCount", totalInterviews);
    updateCounter("offerCount", totalOffers);
    updateCounter("rejectedCount", totalRejected);


    /* =================================
       UPDATE WELCOME MESSAGE
    ================================= */

    const welcomeElement =
        document.getElementById("userName");

    if (welcomeElement) {

        const firstName = (currentUser.name || "STUDENT")
            .trim()
            .split(/\s+/)[0];

        welcomeElement.textContent =
            firstName.toUpperCase() + ".";

    }


    /* =================================
       RECENT APPLICATIONS
    ================================= */

    const recentApplicationsElement =
        document.getElementById("recentApplications");

    if (recentApplicationsElement) {

        const recentApplications = [...userApplications]
            .sort((a, b) =>
                new Date(b.createdAt || b.appliedDate || 0) -
                new Date(a.createdAt || a.appliedDate || 0)
            )
            .slice(0, 5);

        if (recentApplications.length === 0) {

            recentApplicationsElement.innerHTML = `
                <div class="empty-state">
                    NO APPLICATIONS RECORDED
                </div>
            `;

        } else {

            recentApplicationsElement.innerHTML =
                recentApplications.map(application => {

                    const company = escapeDashboardHTML(
                        application.company || "Unknown Company"
                    );

                    const role = escapeDashboardHTML(
                        application.role ||
                        application.title ||
                        "Untitled Role"
                    );

                    const status = escapeDashboardHTML(
                        getApplicationStatus(application)
                    );

                    let date = "NO DATE";

                    if (application.appliedDate) {

                        const parsedDate = new Date(
                            application.appliedDate + "T00:00:00"
                        );

                        if (!Number.isNaN(parsedDate.getTime())) {
                            date = parsedDate.toLocaleDateString(
                                "en-IN",
                                {
                                    day: "2-digit",
                                    month: "short"
                                }
                            );
                        }

                    } else if (application.createdAt) {

                        const parsedDate =
                            new Date(application.createdAt);

                        if (!Number.isNaN(parsedDate.getTime())) {
                            date = parsedDate.toLocaleDateString(
                                "en-IN",
                                {
                                    day: "2-digit",
                                    month: "short"
                                }
                            );
                        }

                    }

                    return `
                        <div class="application-item">

                            <div class="application-info">
                                <strong>${role}</strong>
                                <span>${company}</span>
                            </div>

                            <div class="application-meta">
                                <span class="application-status">
                                    ${status}
                                </span>
                                <small>${escapeDashboardHTML(date)}</small>
                            </div>

                        </div>
                    `;

                }).join("");

        }

    }


    /* =================================
       RECENT ACTIVITY
    ================================= */

    const recentActivityElement =
        document.getElementById("recentActivity");

    if (recentActivityElement) {

        const activities = getActivities();

        // Show only activity belonging to this user.
        const userActivities = activities
            .filter(activity =>
                activity.userId === currentUser.id
            )
            .sort((a, b) =>
                new Date(b.createdAt || 0) -
                new Date(a.createdAt || 0)
            )
            .slice(0, 5);

        if (userActivities.length === 0) {

            recentActivityElement.innerHTML = `
                <div class="empty-state">
                    NO RECENT ACTIVITY
                </div>
            `;

        } else {

            recentActivityElement.innerHTML =
                userActivities.map(activity => {

                    const message = escapeDashboardHTML(
                        activity.message || "Activity recorded"
                    );

                    let date = "";

                    if (activity.createdAt) {

                        const parsedDate =
                            new Date(activity.createdAt);

                        if (!Number.isNaN(parsedDate.getTime())) {
                            date = parsedDate.toLocaleString(
                                "en-IN",
                                {
                                    day: "2-digit",
                                    month: "short",
                                    hour: "2-digit",
                                    minute: "2-digit"
                                }
                            );
                        }

                    }

                    return `
                        <div class="activity-item">
                            <span class="activity-message">
                                ${message}
                            </span>
                            <small>${escapeDashboardHTML(date)}</small>
                        </div>
                    `;

                }).join("");

        }

    }

});


/* =========================================
   SAFE HTML HELPER
========================================= */

function escapeDashboardHTML(value) {

    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);

}
