
/* =========================================
   JOBTRACK — ADMIN DASHBOARD
   Script Shifters / K3P26RE
========================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =================================
       ADMIN ACCESS CONTROL
    ================================= */

    const user = getCurrentUser();

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    if (user.role !== "admin") {
        alert("Admin access only.");
        window.location.href = "dashboard.html";
        return;
    }


    /* =================================
       LOAD SYSTEM DATA
    ================================= */

    const users = getUsers();
    const activities = getActivities();
    const applications = getApplications();
    const totalSavedJobs = getTotalSavedJobs();

    const pad = value =>
        String(value).padStart(2, "0");


    /* =================================
       UPDATE ADMIN STATISTICS
    ================================= */

    function updateStat(elementId, value) {

        const element = document.getElementById(elementId);

        if (element) {
            element.textContent = pad(value);
        }

    }

    updateStat("aUsers", users.length);
    updateStat("aApps", applications.length);
    updateStat("aActs", activities.length);
    updateStat("aSaved", totalSavedJobs);


    /* =================================
       REGISTERED USERS TABLE
    ================================= */

    const userRows = document.getElementById("userRows");

    if (userRows) {

        userRows.replaceChildren();

        if (users.length === 0) {

            const row = document.createElement("tr");
            const cell = document.createElement("td");

            cell.colSpan = 4;
            cell.textContent = "No registered users found.";

            row.appendChild(cell);
            userRows.appendChild(row);

        } else {

            users.forEach(registeredUser => {

                const row = document.createElement("tr");

                const values = [
                    registeredUser.name,
                    registeredUser.email,
                    registeredUser.role,
                    registeredUser.programme || "-"
                ];

                values.forEach(value => {

                    const cell = document.createElement("td");

                    cell.textContent = value || "-";

                    row.appendChild(cell);

                });

                userRows.appendChild(row);

            });

        }

    }


    /* =================================
       RECENT ACTIVITY
    ================================= */

    const actList = document.getElementById("actList");

    if (actList) {

        actList.replaceChildren();

        const recentActivities = [...activities]
            .sort((a, b) =>
                new Date(b.createdAt || 0) -
                new Date(a.createdAt || 0)
            )
            .slice(0, 10);

        if (recentActivities.length === 0) {

            const item = document.createElement("li");

            item.textContent = "No activity yet.";

            actList.appendChild(item);

        } else {

            recentActivities.forEach(activity => {

                const item = document.createElement("li");

                const date = activity.createdAt
                    ? new Date(activity.createdAt)
                        .toLocaleString("en-IN")
                    : "Date unavailable";

                item.textContent =
                    `${date} — ${activity.message || "Activity recorded"}`;

                actList.appendChild(item);

            });

        }

    }

});
