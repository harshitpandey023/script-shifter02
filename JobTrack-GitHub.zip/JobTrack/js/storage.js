
/* =========================================
   JOBTRACK STORAGE SYSTEM
   Script Shifters / K3P26RE

   Uses browser localStorage for persistent
   demo/project data.
========================================= */


/* =========================================
   STORAGE KEYS
========================================= */

const STORAGE_KEYS = {
    USERS: "jobtrack_users",
    CURRENT_USER: "jobtrack_current_user",
    PROFILE: "jobtrack_profile",
    APPLICATIONS: "jobtrack_applications",
    ACTIVITIES: "jobtrack_activities",
    SAVED_JOBS: "jobtrack_saved_jobs"
};


/* =========================================
   GENERIC STORAGE FUNCTIONS
========================================= */

function getStoredData(key, defaultValue = []) {
    try {
        const data = localStorage.getItem(key);

        if (data === null) {
            return defaultValue;
        }

        return JSON.parse(data);

    } catch (error) {
        console.error("Storage read error:", error);
        return defaultValue;
    }
}


function setStoredData(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;

    } catch (error) {
        console.error("Storage write error:", error);
        return false;
    }
}


function removeStoredData(key) {
    try {
        localStorage.removeItem(key);
        return true;

    } catch (error) {
        console.error("Storage removal error:", error);
        return false;
    }
}


/* =========================================
   UNIQUE ID GENERATOR
========================================= */

function generateId(prefix) {
    let uniquePart;

    if (
        typeof crypto !== "undefined" &&
        typeof crypto.randomUUID === "function"
    ) {
        uniquePart = crypto.randomUUID();

    } else {
        uniquePart =
            Date.now() + "-" +
            Math.random().toString(36).slice(2, 10);
    }

    return prefix + "-" + uniquePart;
}


/* =========================================
   USER ACCOUNTS
========================================= */

function seedDemoUsers() {
    const demoUsers = [
        {
            id: "USR001",
            name: "Alex Morgan",
            email: "alex@jobtrack.demo",
            password: "Demo@123",
            role: "student",
            studentId: "",
            programme: "B.Tech Computer Science and Engineering",
            year: "2028"
        },
        {
            id: "ADM001",
            name: "JobTrack Admin",
            email: "admin@jobtrack.demo",
            password: "Admin@123",
            role: "admin",
            studentId: "",
            programme: "Administration",
            year: ""
        }
    ];

    const users = getUsers();
    let changed = false;

    demoUsers.forEach(demoUser => {
        const exists = users.some(user =>
            user.email &&
            user.email.toLowerCase() === demoUser.email.toLowerCase()
        );

        if (!exists) {
            users.push(demoUser);
            changed = true;
        }
    });

    if (changed || !localStorage.getItem(STORAGE_KEYS.USERS)) {
        saveUsers(users);
    }

    return users;
}


function getUsers() {
    const users = getStoredData(STORAGE_KEYS.USERS, []);
    return Array.isArray(users) ? users : [];
}


function saveUsers(users) {
    return setStoredData(STORAGE_KEYS.USERS, users);
}


function findUserByEmail(email) {
    if (!email) return undefined;

    const users = getUsers();

    return users.find(user =>
        user.email &&
        user.email.toLowerCase() === email.trim().toLowerCase()
    );
}


function createUser(userData) {
    if (
        !userData ||
        !userData.name ||
        !userData.email ||
        !userData.password
    ) {
        return {
            success: false,
            message: "Please provide all required account details."
        };
    }

    const users = getUsers();
    const existingUser = findUserByEmail(userData.email);

    if (existingUser) {
        return {
            success: false,
            message: "An account with this email already exists."
        };
    }

    const newUser = {
        id: generateId("USR"),
        name: userData.name.trim(),
        email: userData.email.trim().toLowerCase(),
        password: userData.password,
        studentId: userData.studentId || "",
        programme: userData.programme || "",
        year: userData.year || "",
        role: "student",
        createdAt: new Date().toISOString()
    };

    users.push(newUser);

    const saved = saveUsers(users);

    if (!saved) {
        return {
            success: false,
            message: "Unable to create your account. Please try again."
        };
    }

    return {
        success: true,
        user: newUser
    };
}


/* =========================================
   CURRENT USER
========================================= */

function setCurrentUser(user) {
    if (!user || !user.id) {
        return null;
    }

    const safeUser = {
        id: user.id,
        name: user.name,
        email: user.email,
        studentId: user.studentId || "",
        programme: user.programme || "",
        year: user.year || "",
        role: user.role || "student"
    };

    const saved = setStoredData(
        STORAGE_KEYS.CURRENT_USER,
        safeUser
    );

    return saved ? safeUser : null;
}


function getCurrentUser() {
    return getStoredData(STORAGE_KEYS.CURRENT_USER, null);
}


function isLoggedIn() {
    return getCurrentUser() !== null;
}


function logoutUser() {
    removeStoredData(STORAGE_KEYS.CURRENT_USER);
}


/* =========================================
   PROFILE — USER SPECIFIC
========================================= */

function getProfile() {
    const currentUser = getCurrentUser();

    if (!currentUser) {
        return null;
    }

    const profiles = getStoredData(STORAGE_KEYS.PROFILE, {});

    if (
        !profiles ||
        typeof profiles !== "object" ||
        Array.isArray(profiles)
    ) {
        return null;
    }

    return profiles[currentUser.id] || null;
}


function saveProfile(profile) {
    const currentUser = getCurrentUser();

    if (
        !currentUser ||
        !profile ||
        typeof profile !== "object" ||
        Array.isArray(profile)
    ) {
        return false;
    }

    const profiles = getStoredData(STORAGE_KEYS.PROFILE, {});

    const allProfiles =
        profiles &&
        typeof profiles === "object" &&
        !Array.isArray(profiles)
            ? profiles
            : {};

    allProfiles[currentUser.id] = profile;

    return setStoredData(
        STORAGE_KEYS.PROFILE,
        allProfiles
    );
}


/* =========================================
   APPLICATIONS
========================================= */

function getApplications() {
    const applications = getStoredData(
        STORAGE_KEYS.APPLICATIONS,
        []
    );

    return Array.isArray(applications) ? applications : [];
}


function saveApplications(applications) {
    if (!Array.isArray(applications)) {
        return false;
    }

    return setStoredData(
        STORAGE_KEYS.APPLICATIONS,
        applications
    );
}


function addApplication(application) {
    if (!application || !application.userId) {
        console.error("Application must belong to a user.");
        return null;
    }

    const applications = getApplications();

    const newApplication = {
        ...application,
        id: generateId("APP"),
        createdAt: new Date().toISOString()
    };

    applications.push(newApplication);

    const saved = saveApplications(applications);

    if (!saved) {
        return null;
    }

    return newApplication;
}


/* =========================================
   ACTIVITIES
========================================= */

function getActivities() {
    const activities = getStoredData(
        STORAGE_KEYS.ACTIVITIES,
        []
    );

    return Array.isArray(activities) ? activities : [];
}


function saveActivities(activities) {
    if (!Array.isArray(activities)) {
        return false;
    }

    return setStoredData(
        STORAGE_KEYS.ACTIVITIES,
        activities
    );
}


function addActivity(activity) {
    if (!activity) {
        return null;
    }

    const activities = getActivities();

    const newActivity = {
        ...activity,
        id: generateId("ACT"),
        createdAt: new Date().toISOString()
    };

    activities.push(newActivity);

    const saved = saveActivities(activities);

    if (!saved) {
        return null;
    }

    return newActivity;
}


/* =========================================
   SAVED JOBS — USER SPECIFIC
========================================= */

function getSavedJobs() {
    const storedData = getStoredData(
        STORAGE_KEYS.SAVED_JOBS,
        {}
    );

    const currentUser = getCurrentUser();

    if (!currentUser) {
        return [];
    }

    // Do not assign old global saved jobs
    // to an arbitrary user's account.
    if (Array.isArray(storedData)) {
        return [];
    }

    if (
        !storedData ||
        typeof storedData !== "object"
    ) {
        return [];
    }

    const userSavedJobs = storedData[currentUser.id];

    return Array.isArray(userSavedJobs)
        ? userSavedJobs
        : [];
}


function saveJobs(jobs) {
    if (!Array.isArray(jobs)) {
        return false;
    }

    const currentUser = getCurrentUser();

    if (!currentUser) {
        return false;
    }

    let storedData = getStoredData(
        STORAGE_KEYS.SAVED_JOBS,
        {}
    );

    if (Array.isArray(storedData)) {
        storedData = {};
    }

    if (
        !storedData ||
        typeof storedData !== "object"
    ) {
        storedData = {};
    }

    storedData[currentUser.id] = jobs;

    return setStoredData(
        STORAGE_KEYS.SAVED_JOBS,
        storedData
    );
}


/* =========================================
   TOGGLE SAVED JOB
========================================= */

function toggleSavedJob(jobId) {
    if (!jobId) {
        return false;
    }

    const savedJobs = getSavedJobs();
    const index = savedJobs.indexOf(jobId);

    // Add job
    if (index === -1) {
        savedJobs.push(jobId);

        if (!saveJobs(savedJobs)) {
            return false;
        }

        return true;
    }

    // Remove job
    savedJobs.splice(index, 1);

    if (!saveJobs(savedJobs)) {
        return true;
    }

    return false;
}


function isJobSaved(jobId) {
    return getSavedJobs().includes(jobId);
}


/* =========================================
   TOTAL SAVED JOBS — ALL USERS
========================================= */

function getTotalSavedJobs() {
    const storedData = getStoredData(
        STORAGE_KEYS.SAVED_JOBS,
        {}
    );

    if (Array.isArray(storedData)) {
        return storedData.length;
    }

    if (
        !storedData ||
        typeof storedData !== "object"
    ) {
        return 0;
    }

    return Object.values(storedData).reduce(
        (total, jobs) => {
            return total + (
                Array.isArray(jobs) ? jobs.length : 0
            );
        },
        0
    );
}
