
/* =========================================
   JOBTRACK AUTHENTICATION
   Script Shifters / K3P26RE

   Educational demo only: credentials are
   stored in browser localStorage, not secure
   enough for a production application.
========================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =================================
       SEED DEMO ACCOUNTS
    ================================= */

    seedDemoUsers();


    /* =================================
       GET HTML ELEMENTS
    ================================= */

    const loginForm = document.getElementById("loginForm");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const togglePassword = document.getElementById("togglePassword");
    const message = document.getElementById("loginMessage");


    /* =================================
       SHOW / HIDE PASSWORD
    ================================= */

    if (togglePassword && passwordInput) {

        togglePassword.addEventListener("click", () => {

            const showing = passwordInput.type === "password";

            passwordInput.type = showing ? "text" : "password";

            togglePassword.textContent =
                showing ? "HIDE" : "SHOW";

        });

    }


    /* =================================
       LOGIN FORM
    ================================= */

    if (!loginForm) return;

    loginForm.addEventListener("submit", event => {

        event.preventDefault();

        if (message) {
            message.textContent = "";
        }

        const email = emailInput
            ? emailInput.value.trim().toLowerCase()
            : "";

        const password = passwordInput
            ? passwordInput.value
            : "";


        /* =================================
           VALIDATION
        ================================= */

        if (!email || !password) {

            showMessage(
                "ERROR / Please complete all fields.",
                "error"
            );

            return;

        }


        /* =================================
           CHECK CREDENTIALS
        ================================= */

        const user = findUserByEmail(email);

        if (!user || user.password !== password) {

            showMessage(
                "ERROR / Incorrect email or password.",
                "error"
            );

            return;

        }


        /* =================================
           CREATE LOGIN SESSION
        ================================= */

        const session = setCurrentUser(user);

        if (!session) {

            showMessage(
                "ERROR / Unable to create login session. Please try again.",
                "error"
            );

            return;

        }


        /* =================================
           RECORD LOGIN ACTIVITY
        ================================= */

        addActivity({

            userId: user.id,

            type: "login",

            message: `${user.name} logged in.`

        });


        /* =================================
           SUCCESS & REDIRECT
        ================================= */

        showMessage(
            "SUCCESS / Access granted. Redirecting...",
            "success"
        );

        window.location.href =
            user.role === "admin"
                ? "admin.html"
                : "dashboard.html";

    });


    /* =================================
       MESSAGE HELPER
    ================================= */

    function showMessage(text, type) {

        if (!message) return;

        message.textContent = text;

        message.style.color =
            type === "success"
                ? "#9b6cff"
                : "#ff7777";

    }

});
