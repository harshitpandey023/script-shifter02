
/* =========================================
   JOBTRACK — JOB DISCOVERY SYSTEM
   Script Shifters / K3P26RE
========================================= */


/* =========================================
   GLOBAL DATA
========================================= */

let allJobs = [];
let filteredJobs = [];


/* =========================================
   DOM ELEMENTS
========================================= */

const jobsGrid = document.getElementById("jobsGrid");
const jobSearch = document.getElementById("jobSearch");
const categoryFilter = document.getElementById("categoryFilter");
const typeFilter = document.getElementById("typeFilter");
const locationFilter = document.getElementById("locationFilter");
const clearFilters = document.getElementById("clearFilters");
const jobCount = document.getElementById("jobCount");
const resultCount = document.getElementById("resultCount");


/* =========================================
   SAFE HTML HELPER
========================================= */

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}


function normalize(value) {
    return String(value ?? "").trim().toLowerCase();
}


/* =========================================
   LOAD JOBS
========================================= */

async function loadJobs() {
    try {
        const response = await fetch("data/jobs.json");

        if (!response.ok) {
            throw new Error("Unable to load jobs.json");
        }

        const data = await response.json();

        if (!Array.isArray(data)) {
            throw new Error("Invalid jobs database format.");
        }

        allJobs = data.filter(job => job && job.id);

        filteredJobs = [...allJobs];

        updateCounts();
        renderJobs();

    } catch (error) {
        console.error("Job loading error:", error);

        if (jobsGrid) {
            jobsGrid.innerHTML = `
                <div class="jobs-empty">
                    <strong>DATABASE ERROR</strong>
                    Unable to load job opportunities.
                    Please open the project using VS Code Live Server.
                </div>
            `;
        }

        if (jobCount) jobCount.textContent = "00";
        if (resultCount) resultCount.textContent = "00 RESULTS";
    }
}


/* =========================================
   RENDER JOBS
========================================= */

function renderJobs() {
    if (!jobsGrid) return;

    if (filteredJobs.length === 0) {
        jobsGrid.innerHTML = `
            <div class="jobs-empty">
                <strong>NO MATCHES FOUND</strong>
                Try changing your search or filters.
            </div>
        `;
        return;
    }

    jobsGrid.innerHTML = filteredJobs
        .map(job => createJobCard(job))
        .join("");

    attachJobEvents();
}


/* =========================================
   CREATE JOB CARD
========================================= */

function createJobCard(job) {
    const saved = isJobSaved(job.id);

    const skills = (Array.isArray(job.skills) ? job.skills : [])
        .map(skill => `
            <span class="job-tag">
                ${escapeHTML(skill)}
            </span>
        `)
        .join("");

    return `
        <article class="job-card" data-job-id="${escapeHTML(job.id)}">

            <div class="job-card-top">

                <div class="company-badge">
                    ${escapeHTML((job.company || "?").charAt(0).toUpperCase())}
                </div>

                <button
                    class="save-job ${saved ? "saved" : ""}"
                    data-save-id="${escapeHTML(job.id)}"
                    aria-label="${saved ? "Remove saved job" : "Save job"}"
                    title="${saved ? "Remove saved job" : "Save job"}"
                    aria-pressed="${saved}"
                    type="button"
                >
                    ${saved ? "★" : "☆"}
                </button>

            </div>

            <div class="job-company">
                ${escapeHTML(job.company || "Company not specified")}
            </div>

            <h2 class="job-title">
                ${escapeHTML(job.title || "Untitled position")}
            </h2>

            <p class="job-description">
                ${escapeHTML(job.description || "No description available.")}
            </p>

            <div class="job-meta">

                <span class="job-tag highlight">
                    ${escapeHTML(job.category || "Other")}
                </span>

                <span class="job-tag">
                    ${escapeHTML(job.type || "Not specified")}
                </span>

                <span class="job-tag">
                    ${escapeHTML(job.location || "Not specified")}
                </span>

                ${skills}

            </div>

            <div class="job-card-bottom">

                <span class="job-salary">
                    ${escapeHTML(job.salary || "Salary not specified")}
                </span>

                <a
                    href="apply.html?job=${encodeURIComponent(job.id)}"
                    class="view-job"
                >
                    APPLY →
                </a>

            </div>

        </article>
    `;
}


/* =========================================
   SAVE / UNSAVE JOBS
========================================= */

function attachJobEvents() {
    const saveButtons = document.querySelectorAll(".save-job");

    saveButtons.forEach(button => {
        button.addEventListener("click", () => {
            const jobId = button.dataset.saveId;

            const saved = toggleSavedJob(jobId);

            // Refresh from storage to reflect the actual state.
            const isSaved = isJobSaved(jobId);

            button.classList.toggle("saved", isSaved);
            button.textContent = isSaved ? "★" : "☆";

            button.setAttribute(
                "aria-label",
                isSaved ? "Remove saved job" : "Save job"
            );

            button.setAttribute(
                "title",
                isSaved ? "Remove saved job" : "Save job"
            );

            button.setAttribute("aria-pressed", String(isSaved));

            if (saved === isSaved) {
                button.title = isSaved ? "Remove saved job" : "Save job";
            }
        });
    });
}


/* =========================================
   SEARCH + FILTER
========================================= */

function filterJobs() {
    const searchTerm = normalize(jobSearch?.value);
    const category = normalize(categoryFilter?.value);
    const type = normalize(typeFilter?.value);
    const location = normalize(locationFilter?.value);

    filteredJobs = allJobs.filter(job => {
        const skills = Array.isArray(job.skills) ? job.skills : [];

        const searchableText = [
            job.company,
            job.title,
            job.category,
            job.type,
            job.location,
            job.description,
            ...skills
        ]
            .map(normalize)
            .join(" ");

        const matchesSearch =
            !searchTerm || searchableText.includes(searchTerm);

        const matchesCategory =
            !category || category === "all" ||
            normalize(job.category) === category;

        const matchesType =
            !type || type === "all" ||
            normalize(job.type) === type;

        const matchesLocation =
            !location || location === "all" ||
            normalize(job.location) === location;

        return (
            matchesSearch &&
            matchesCategory &&
            matchesType &&
            matchesLocation
        );
    });

    updateCounts();
    renderJobs();
}


/* =========================================
   COUNTERS
========================================= */

function updateCounts() {
    const total = allJobs.length;
    const results = filteredJobs.length;

    if (jobCount) {
        jobCount.textContent = String(total).padStart(2, "0");
    }

    if (resultCount) {
        resultCount.textContent =
            `${String(results).padStart(2, "0")} RESULTS`;
    }
}


/* =========================================
   CLEAR FILTERS
========================================= */

function resetFilters() {
    if (jobSearch) jobSearch.value = "";
    if (categoryFilter) categoryFilter.value = "all";
    if (typeFilter) typeFilter.value = "all";
    if (locationFilter) locationFilter.value = "all";

    filteredJobs = [...allJobs];

    updateCounts();
    renderJobs();
}


/* =========================================
   SEARCH EVENTS
========================================= */

if (jobSearch) {
    jobSearch.addEventListener("input", filterJobs);
}

if (categoryFilter) {
    categoryFilter.addEventListener("change", filterJobs);
}

if (typeFilter) {
    typeFilter.addEventListener("change", filterJobs);
}

if (locationFilter) {
    locationFilter.addEventListener("change", filterJobs);
}

if (clearFilters) {
    clearFilters.addEventListener("click", resetFilters);
}


/* =========================================
   START
========================================= */

loadJobs();
