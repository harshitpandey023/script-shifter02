# JobTrack

**Your career. Tracked with precision.**

JobTrack is a frontend-based job application management platform built for students and emerging professionals. It brings job discovery, application tracking, saved opportunities, recruitment activity, and profile management into one workspace.

## Features

- Student registration and demo login
- Dashboard overview
- Job browsing and application submission
- Application status tracking
- Saved jobs
- Recruitment activity tracking
- Profile and resume management
- Admin panel

## Built with

- HTML5
- CSS3
- Vanilla JavaScript
- Browser LocalStorage
- JSON sample data

## Run locally

This project is a static frontend. Because some pages load JSON files with `fetch()`, run it through a local web server rather than opening the HTML files directly.

1. Download or clone this repository.
2. Open the project folder in VS Code.
3. Start a local server from the project root. For example, install the **Live Server** extension and select **Go Live** on `index.html`.
4. Open the local URL provided by the server.

## Demo accounts

| Role | Email | Password |
|---|---|---|
| Student | `alex@jobtrack.demo` | `Demo@123` |
| Admin | `admin@jobtrack.demo` | `Admin@123` |

These are demonstration credentials only. Do not use real passwords or personal information in this project.

## Project pages

- `index.html` — landing page
- `register.html` — student registration
- `login.html` — login
- `dashboard.html` — student dashboard
- `jobs.html` — job listings
- `apply.html` — application form
- `applications.html` — application tracker
- `saved.html` — saved jobs
- `profile.html` — profile management
- `admin.html` — admin panel

## Project structure

```text
JobTrack/
├── index.html
├── login.html
├── register.html
├── dashboard.html
├── jobs.html
├── apply.html
├── applications.html
├── saved.html
├── profile.html
├── admin.html
├── css/          # Stylesheets
├── js/           # Frontend scripts
└── data/         # Sample JSON data
```

## Important notes

- This is an educational frontend project, not a production-ready recruitment system.
- Authentication and persistence are simulated in the browser using LocalStorage.
- Passwords in the sample implementation are not securely hashed. Do not deploy this project with real user accounts or sensitive data.
- Data saved in LocalStorage is specific to the browser and device being used.

## Team

**Organisation:** Lovely Professional University  
**Section:** K3P26RE  
**Team:** Script Shifters
